import { sql } from "drizzle-orm";
import { pgTable, text, varchar, decimal, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const items = pgTable("items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  series: text("series"),
  category: text("category").notNull(),
  status: text("status").notNull(), // 'owned', 'wishlist', 'sold', 'pending-sale'
  purchasePrice: decimal("purchase_price", { precision: 10, scale: 2 }),
  purchaseDate: timestamp("purchase_date"),
  soldPrice: decimal("sold_price", { precision: 10, scale: 2 }),
  soldDate: timestamp("sold_date"),
  sellingPrice: decimal("selling_price", { precision: 10, scale: 2 }),
  buyerName: text("buyer_name"),
  shippingCarrier: text("shipping_carrier"),
  trackingNumber: text("tracking_number"),
  soldShippingCarrier: text("sold_shipping_carrier"),
  soldTrackingNumber: text("sold_tracking_number"),
  boughtFrom: text("bought_from"),
  notes: text("notes"),
  images: jsonb("images").$type<string[]>().default([]),
  isWishlist: text("is_wishlist").default("false"),
  // Legacy field for backwards compatibility
  price: decimal("price", { precision: 10, scale: 2 }),
});

export const insertItemSchema = createInsertSchema(items).omit({
  id: true,
}).extend({
  purchasePrice: z.string().optional(),
  purchaseDate: z.string().optional(),
  soldPrice: z.string().optional(),
  soldDate: z.string().optional(),
  sellingPrice: z.string().optional(),
  buyerName: z.string().optional(),
  shippingCarrier: z.string().optional(),
  trackingNumber: z.string().optional(),
  soldShippingCarrier: z.string().optional(),
  soldTrackingNumber: z.string().optional(),
  boughtFrom: z.string().optional(),
  images: z.array(z.string()).optional(),
  // Legacy field for backwards compatibility
  price: z.string().optional(),
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;
