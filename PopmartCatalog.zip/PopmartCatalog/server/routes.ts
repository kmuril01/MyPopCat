import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertItemSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all items
  app.get("/api/items", async (req, res) => {
    try {
      const { category, status, search } = req.query;
      
      let items;
      if (search) {
        items = await storage.searchItems(search as string);
      } else if (category) {
        items = await storage.getItemsByCategory(category as string);
      } else if (status) {
        items = await storage.getItemsByStatus(status as string);
      } else {
        items = await storage.getAllItems();
      }
      
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch items" });
    }
  });

  // Get single item
  app.get("/api/items/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch item" });
    }
  });

  // Create new item
  app.post("/api/items", upload.array('images', 5), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      const imageUrls = files?.map(file => `/uploads/${file.filename}`) || [];
      
      const itemData = {
        ...req.body,
        images: imageUrls,
      };

      const validatedData = insertItemSchema.parse(itemData);
      const item = await storage.createItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid item data" });
    }
  });

  // Update item
  app.patch("/api/items/:id", upload.array('images', 5), async (req, res) => {
    try {
      const files = req.files as Express.Multer.File[];
      const itemData = { ...req.body };
      
      // Handle images: combine existing and new
      let allImages: string[] = [];
      
      // Add existing images if provided
      if (req.body.existingImages) {
        try {
          const existingImages = JSON.parse(req.body.existingImages);
          if (Array.isArray(existingImages)) {
            allImages = [...existingImages];
          }
        } catch (e) {
          // If parsing fails, ignore existing images
        }
      }
      
      // Add new uploaded images
      if (files && files.length > 0) {
        const newImageUrls = files.map(file => `/uploads/${file.filename}`);
        allImages = [...allImages, ...newImageUrls];
      }
      
      // Update images only if there are changes
      if (files?.length > 0 || req.body.existingImages) {
        itemData.images = allImages;
      }

      const validatedData = insertItemSchema.partial().parse(itemData);
      const item = await storage.updateItem(req.params.id, validatedData);
      
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: error instanceof Error ? error.message : "Invalid item data" });
    }
  });

  // Delete item
  app.delete("/api/items/:id", async (req, res) => {
    try {
      const success = await storage.deleteItem(req.params.id);
      if (!success) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json({ message: "Item deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete item" });
    }
  });

  // Serve uploaded images
  app.use('/uploads', (req, res, next) => {
    res.setHeader('Cache-Control', 'public, max-age=86400'); // 1 day cache
    next();
  });
  app.use('/uploads', express.static(uploadDir));

  // Get collection stats
  app.get("/api/stats", async (req, res) => {
    try {
      const items = await storage.getAllItems();
      const stats = {
        total: items.length,
        owned: items.filter(item => item.status === 'owned').length,
        wishlist: items.filter(item => item.status === 'wishlist').length,
        sold: items.filter(item => item.status === 'sold').length,
        "pending-sale": items.filter(item => item.status === 'pending-sale').length,
        totalValue: items
          .filter(item => item.status === 'owned' && (item.purchasePrice || item.price))
          .reduce((sum, item) => sum + parseFloat(item.purchasePrice || item.price || '0'), 0),
        categories: {
          labubu: items.filter(item => item.category.toLowerCase() === 'labubu').length,
          skullpanda: items.filter(item => item.category.toLowerCase() === 'skullpanda').length,
          crybaby: items.filter(item => item.category.toLowerCase() === 'crybaby').length,
          other: items.filter(item => !['labubu', 'skullpanda', 'crybaby'].includes(item.category.toLowerCase())).length,
        }
      };
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
