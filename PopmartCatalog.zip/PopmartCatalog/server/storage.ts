import { type Item, type InsertItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getItem(id: string): Promise<Item | undefined>;
  getAllItems(): Promise<Item[]>;
  getItemsByCategory(category: string): Promise<Item[]>;
  getItemsByStatus(status: string): Promise<Item[]>;
  searchItems(query: string): Promise<Item[]>;
  createItem(item: InsertItem): Promise<Item>;
  updateItem(id: string, item: Partial<InsertItem>): Promise<Item | undefined>;
  deleteItem(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private items: Map<string, Item>;

  constructor() {
    this.items = new Map();
  }

  async getItem(id: string): Promise<Item | undefined> {
    return this.items.get(id);
  }

  async getAllItems(): Promise<Item[]> {
    return Array.from(this.items.values());
  }

  async getItemsByCategory(category: string): Promise<Item[]> {
    return Array.from(this.items.values()).filter(
      (item) => item.category.toLowerCase() === category.toLowerCase()
    );
  }

  async getItemsByStatus(status: string): Promise<Item[]> {
    return Array.from(this.items.values()).filter(
      (item) => item.status === status
    );
  }

  async searchItems(query: string): Promise<Item[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.items.values()).filter(
      (item) =>
        item.name.toLowerCase().includes(lowerQuery) ||
        item.series?.toLowerCase().includes(lowerQuery) ||
        item.category.toLowerCase().includes(lowerQuery)
    );
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    const id = randomUUID();
    const item: Item = {
      ...insertItem,
      id,
      series: insertItem.series || null,
      notes: insertItem.notes || null,
      price: insertItem.price || null,
      purchasePrice: insertItem.purchasePrice || null,
      soldPrice: insertItem.soldPrice || null,
      sellingPrice: insertItem.sellingPrice || null,
      buyerName: insertItem.buyerName || null,
      shippingCarrier: insertItem.shippingCarrier || null,
      trackingNumber: insertItem.trackingNumber || null,
      soldShippingCarrier: insertItem.soldShippingCarrier || null,
      soldTrackingNumber: insertItem.soldTrackingNumber || null,
      boughtFrom: insertItem.boughtFrom || null,
      purchaseDate: insertItem.purchaseDate ? new Date(insertItem.purchaseDate) : null,
      soldDate: insertItem.soldDate ? new Date(insertItem.soldDate) : null,
      images: insertItem.images || [],
      isWishlist: insertItem.isWishlist || "false",
    };
    this.items.set(id, item);
    return item;
  }

  async updateItem(id: string, updateData: Partial<InsertItem>): Promise<Item | undefined> {
    const existingItem = this.items.get(id);
    if (!existingItem) return undefined;

    const updatedItem: Item = {
      ...existingItem,
      ...updateData,
      price: updateData.price !== undefined ? updateData.price : existingItem.price,
      purchaseDate: updateData.purchaseDate !== undefined 
        ? (updateData.purchaseDate ? new Date(updateData.purchaseDate) : null)
        : existingItem.purchaseDate,
      soldDate: updateData.soldDate !== undefined 
        ? (updateData.soldDate ? new Date(updateData.soldDate) : null)
        : existingItem.soldDate,
      images: updateData.images !== undefined ? updateData.images : existingItem.images,
    };

    this.items.set(id, updatedItem);
    return updatedItem;
  }

  async deleteItem(id: string): Promise<boolean> {
    return this.items.delete(id);
  }
}

export const storage = new MemStorage();
