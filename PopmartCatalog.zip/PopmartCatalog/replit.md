# Overview

MyPopCat is a full-stack collectibles catalog application built for managing collections of Popmart toys and figures across 40+ series including Labubu, Skullpanda, Crybaby, Molly, Harry Potter, DIMOO, and many others. The application allows users to track their collection items with conditional field visibility based on status: Owned items show purchase price and date, Sold items add sold price and date, Pending Sale items include selling price and buyer name, while Wishlist items only show core details. Features a modern React frontend with shadcn/ui components and an Express.js backend with in-memory storage for fast prototyping.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on top of Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming support
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation using @hookform/resolvers

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM for type-safe database operations
- **API Design**: RESTful API with CRUD operations for items and statistics
- **File Uploads**: Multer middleware for handling image uploads with file type validation
- **Development**: Hot reload with tsx for development server

## Data Storage
- **Database**: PostgreSQL with Neon serverless connection
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Strategy**: In-memory storage implementation with interface for easy database integration
- **File Storage**: Local file system for uploaded images with organized directory structure

## Authentication & Authorization
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **Security**: Basic request logging and error handling middleware
- **File Security**: Image-only upload restrictions with file size limits (10MB)

## External Dependencies
- **Database**: Neon PostgreSQL serverless database (@neondatabase/serverless)
- **UI Components**: Comprehensive Radix UI component library for accessibility
- **Validation**: Zod for runtime type checking and schema validation
- **Date Handling**: date-fns for date manipulation and formatting
- **Development Tools**: 
  - Replit-specific plugins for development environment integration
  - ESBuild for production bundling
  - PostCSS with Autoprefixer for CSS processing

## Key Features
- **Collection Management**: Add, edit, delete, and view collectible items with full CRUD operations
- **Conditional Field Visibility**: Status-based form fields (Owned: purchase price/date; Sold: adds sold price/date; Pending Sale: adds selling price/buyer name; Wishlist: core fields only)
- **Comprehensive Categories**: 40+ Popmart series including Molly, Harry Potter, DIMOO, Peach Riot, Pucky, Disney, and more (sorted by name descending)
- **Image Handling**: Multiple image upload (up to 5), preview, and management functionality
- **Search & Filter**: Category-based filtering, text search, and status filtering capabilities
- **Dual View Modes**: Grid and list layout options for viewing collections
- **Statistics Dashboard**: Collection value tracking and category breakdowns with pending sale status
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Type Safety**: End-to-end TypeScript with shared schema validation

## Recent Changes (July 31, 2025)
- Renamed "Price" to "Purchase Price" across all forms and displays
- Added "Pending Sale" status with selling price and buyer name fields
- Implemented conditional field visibility based on item status
- Expanded category list to 40+ Popmart series sorted by name ascending (changed from descending)
- Added edit functionality for existing items with image management
- Updated data schema to support new purchasePrice, soldPrice, sellingPrice, buyerName, and boughtFrom fields
- Enhanced statistics to include pending sale counts
- Maintained backward compatibility with existing price field
- Added shipping carrier and tracking fields for owned items
- Added separate shipping carrier and tracking fields for sold items  
- Implemented retention of selling price and buyer name when status changes from Pending Sale to Sold
- Updated shipping carrier dropdown to include: 4PX, Amazon Logistics, DHL, FEDEX, GOFO, SF Express, UPS, USPS, Yun Express (all in ascending order)
- Added "Bought From" field for Owned status with options: Discord, eBay, Facebook, Instagram, Other, Pop Upon Delivery, PopNow, Private Seller, StockX, TikTok, WhatNot (all in ascending order)
- Replaced main page category buttons with comprehensive dropdown containing all 40+ categories
- Updated sidebar to use dropdown instead of individual category buttons for better user experience
- Reordered form fields for Sold status: Sold Price/Date first, then Selling Price/Buyer Name, then Purchase Price/Date
- Reordered form fields for Pending Sale status: Selling Price/Buyer Name first, then Purchase Price/Date