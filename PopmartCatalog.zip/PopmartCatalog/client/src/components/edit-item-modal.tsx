import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CloudUpload, X } from "lucide-react";
import { insertItemSchema, type Item } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const formSchema = insertItemSchema.extend({
  name: z.string().min(1, "Item name is required"),
  category: z.string().min(1, "Category is required"),
  status: z.string().min(1, "Status is required"),
});

type FormData = z.infer<typeof formSchema>;

interface EditItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  item: Item;
}

export function EditItemModal({ isOpen, onClose, onSuccess, item }: EditItemModalProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [existingImages, setExistingImages] = useState<string[]>(item.images || []);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: item.name,
      series: item.series || "",
      category: item.category,
      status: item.status,
      purchasePrice: item.purchasePrice || "",
      purchaseDate: item.purchaseDate ? new Date(item.purchaseDate).toISOString().split('T')[0] : "",
      soldPrice: item.soldPrice || "",
      soldDate: item.soldDate ? new Date(item.soldDate).toISOString().split('T')[0] : "",
      sellingPrice: item.sellingPrice || "",
      buyerName: item.buyerName || "",
      shippingCarrier: item.shippingCarrier || "",
      trackingNumber: item.trackingNumber || "",
      soldShippingCarrier: item.soldShippingCarrier || "",
      soldTrackingNumber: item.soldTrackingNumber || "",
      boughtFrom: item.boughtFrom || "",
      notes: item.notes || "",
      isWishlist: item.isWishlist || "false",
    },
  });

  useEffect(() => {
    if (isOpen) {
      setExistingImages(item.images || []);
      form.reset({
        name: item.name,
        series: item.series || "",
        category: item.category,
        status: item.status,
        purchasePrice: item.purchasePrice || "",
        purchaseDate: item.purchaseDate ? new Date(item.purchaseDate).toISOString().split('T')[0] : "",
        soldPrice: item.soldPrice || "",
        soldDate: item.soldDate ? new Date(item.soldDate).toISOString().split('T')[0] : "",
        sellingPrice: item.sellingPrice || "",
        buyerName: item.buyerName || "",
        shippingCarrier: item.shippingCarrier || "",
        trackingNumber: item.trackingNumber || "",
        soldShippingCarrier: item.soldShippingCarrier || "",
        soldTrackingNumber: item.soldTrackingNumber || "",
        boughtFrom: item.boughtFrom || "",
        notes: item.notes || "",
        isWishlist: item.isWishlist || "false",
      });
    }
  }, [isOpen, item, form]);

  const updateItemMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const formData = new FormData();
      
      // Append all form fields
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      });

      // Append existing images to keep
      if (existingImages.length > 0) {
        formData.append('existingImages', JSON.stringify(existingImages));
      }

      // Append new files
      selectedFiles.forEach((file) => {
        formData.append('images', file);
      });

      const response = await fetch(`/api/items/${item.id}`, {
        method: 'PATCH',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to update item');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Item updated successfully",
        description: "Your item has been updated in your collection.",
      });
      handleClose();
      onSuccess();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update item. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const totalImages = existingImages.length + files.length;
    
    if (totalImages > 5) {
      toast({
        title: "Too many files",
        description: "You can only have up to 5 images total.",
        variant: "destructive",
      });
      return;
    }

    setSelectedFiles(files);

    // Create preview URLs
    const urls = files.map(file => URL.createObjectURL(file));
    setPreviewUrls(urls);
  };

  const removeNewFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newUrls = previewUrls.filter((_, i) => i !== index);
    
    // Revoke the removed URL
    URL.revokeObjectURL(previewUrls[index]);
    
    setSelectedFiles(newFiles);
    setPreviewUrls(newUrls);
  };

  const removeExistingImage = (index: number) => {
    const newImages = existingImages.filter((_, i) => i !== index);
    setExistingImages(newImages);
  };

  const handleClose = () => {
    // Revoke all preview URLs
    previewUrls.forEach(url => URL.revokeObjectURL(url));
    setPreviewUrls([]);
    setSelectedFiles([]);
    setExistingImages(item.images || []);
    form.reset();
    onClose();
  };

  const onSubmit = (data: FormData) => {
    updateItemMutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Edit Item</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Existing Images */}
            {existingImages.length > 0 && (
              <div>
                <Label className="block text-sm font-medium mb-2">Current Images</Label>
                <div className="grid grid-cols-4 gap-4 mb-4">
                  {existingImages.map((imageUrl, index) => (
                    <div key={index} className="relative">
                      <img
                        src={imageUrl}
                        alt={`Current ${index + 1}`}
                        className="w-full h-20 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6"
                        onClick={() => removeExistingImage(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* New Image Upload */}
            <div>
              <Label className="block text-sm font-medium mb-2">Add New Images</Label>
              <label className="relative block border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                <CloudUpload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-gray-600">Click to upload or drag and drop</p>
                <p className="text-xs text-gray-500 mt-1">PNG, JPG up to 10MB (max 5 total)</p>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileChange}
                  className="sr-only"
                />
              </label>

              {/* New Image Previews */}
              {previewUrls.length > 0 && (
                <div className="mt-4 grid grid-cols-4 gap-4">
                  {previewUrls.map((url, index) => (
                    <div key={index} className="relative">
                      <img
                        src={url}
                        alt={`New ${index + 1}`}
                        className="w-full h-20 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6"
                        onClick={() => removeNewFile(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Name *</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Labubu Macaron Series" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="series"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Series</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Special Edition" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="Anya">Anya</SelectItem>
                        <SelectItem value="AZURA">AZURA</SelectItem>
                        <SelectItem value="BAZBON">BAZBON</SelectItem>
                        <SelectItem value="BOBO & COCO">BOBO & COCO</SelectItem>
                        <SelectItem value="BUNNY">BUNNY</SelectItem>
                        <SelectItem value="crybaby">Crybaby</SelectItem>
                        <SelectItem value="DC">DC</SelectItem>
                        <SelectItem value="DIMOO">DIMOO</SelectItem>
                        <SelectItem value="Disney">Disney</SelectItem>
                        <SelectItem value="DUCKOO">DUCKOO</SelectItem>
                        <SelectItem value="FLABJACKS">FLABJACKS</SelectItem>
                        <SelectItem value="Flying DongDong">Flying DongDong</SelectItem>
                        <SelectItem value="FUBOBO">FUBOBO</SelectItem>
                        <SelectItem value="Garfield">Garfield</SelectItem>
                        <SelectItem value="Hacipupu">Hacipupu</SelectItem>
                        <SelectItem value="Harry Potter">Harry Potter</SelectItem>
                        <SelectItem value="Hirono">Hirono</SelectItem>
                        <SelectItem value="inosoul">inosoul</SelectItem>
                        <SelectItem value="Jackson Wang">Jackson Wang</SelectItem>
                        <SelectItem value="KUBO">KUBO</SelectItem>
                        <SelectItem value="labubu">Labubu</SelectItem>
                        <SelectItem value="MIGO">MIGO</SelectItem>
                        <SelectItem value="MINICO">MINICO</SelectItem>
                        <SelectItem value="Minions">Minions</SelectItem>
                        <SelectItem value="Molly">Molly</SelectItem>
                        <SelectItem value="Nori">Nori</SelectItem>
                        <SelectItem value="Nyota">Nyota</SelectItem>
                        <SelectItem value="other">Other Series</SelectItem>
                        <SelectItem value="Peach Riot">Peach Riot</SelectItem>
                        <SelectItem value="Pino Jelly">Pino Jelly</SelectItem>
                        <SelectItem value="POLAR">POLAR</SelectItem>
                        <SelectItem value="POPMART">POPMART</SelectItem>
                        <SelectItem value="Pucky">Pucky</SelectItem>
                        <SelectItem value="SATYR RORY">SATYR RORY</SelectItem>
                        <SelectItem value="skullpanda">Skullpanda</SelectItem>
                        <SelectItem value="Snoopy">Snoopy</SelectItem>
                        <SelectItem value="SpongeBob">SpongeBob</SelectItem>
                        <SelectItem value="Sweet Bean">Sweet Bean</SelectItem>
                        <SelectItem value="The Monsters">The Monsters</SelectItem>
                        <SelectItem value="Twinkle Twinkle">Twinkle Twinkle</SelectItem>
                        <SelectItem value="VITA">VITA</SelectItem>
                        <SelectItem value="YOKI">YOKI</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status *</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="owned">Owned</SelectItem>
                        <SelectItem value="wishlist">Wishlist</SelectItem>
                        <SelectItem value="sold">Sold</SelectItem>
                        <SelectItem value="pending-sale">Pending Sale</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Owned status - Purchase Price and Purchase Date */}
            {form.watch("status") === "owned" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="purchasePrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchase Price</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                          <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="purchaseDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchase Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {/* Pending Sale status - Selling Price and Buyer Name first, then Purchase Price and Purchase Date */}
            {form.watch("status") === "pending-sale" && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="sellingPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Selling Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                            <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="buyerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Buyer Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter buyer's name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="purchasePrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchase Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                            <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="purchaseDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchase Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </>
            )}

            {/* Shipping fields for Owned status */}
            {form.watch("status") === "owned" && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="shippingCarrier"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shipping Carrier</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select carrier" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="4px">4PX</SelectItem>
                            <SelectItem value="amazon">Amazon Logistics</SelectItem>
                            <SelectItem value="dhl">DHL</SelectItem>
                            <SelectItem value="fedex">FEDEX</SelectItem>
                            <SelectItem value="gofo">GOFO</SelectItem>
                            <SelectItem value="sf">SF Express</SelectItem>
                            <SelectItem value="ups">UPS</SelectItem>
                            <SelectItem value="usps">USPS</SelectItem>
                            <SelectItem value="yun">Yun Express</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="trackingNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tracking Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter tracking number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="boughtFrom"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bought From</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select where you bought this" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="discord">Discord</SelectItem>
                          <SelectItem value="ebay">eBay</SelectItem>
                          <SelectItem value="facebook">Facebook</SelectItem>
                          <SelectItem value="instagram">Instagram</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                          <SelectItem value="pop-upon-delivery">Pop Upon Delivery</SelectItem>
                          <SelectItem value="popnow">PopNow</SelectItem>
                          <SelectItem value="private-seller">Private Seller</SelectItem>
                          <SelectItem value="stockx">StockX</SelectItem>
                          <SelectItem value="tiktok">TikTok</SelectItem>
                          <SelectItem value="whatnot">WhatNot</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </>
            )}

            {/* Additional fields for Sold items - retains selling price and buyer name */}
            {form.watch("status") === "sold" && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="soldPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sold Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                            <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="soldDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sold Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Retain selling price and buyer name from pending sale */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="sellingPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Selling Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                            <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="buyerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Buyer Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter buyer's name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Purchase Price and Purchase Date */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="purchasePrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchase Price</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                            <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="purchaseDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purchase Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Shipping fields for Sold status */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="soldShippingCarrier"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sold Shipping Carrier</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select carrier" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="4px">4PX</SelectItem>
                            <SelectItem value="amazon">Amazon Logistics</SelectItem>
                            <SelectItem value="dhl">DHL</SelectItem>
                            <SelectItem value="fedex">FEDEX</SelectItem>
                            <SelectItem value="gofo">GOFO</SelectItem>
                            <SelectItem value="sf">SF Express</SelectItem>
                            <SelectItem value="ups">UPS</SelectItem>
                            <SelectItem value="usps">USPS</SelectItem>
                            <SelectItem value="yun">Yun Express</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="soldTrackingNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Sold Tracking Number</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter tracking number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </>
            )}

            {/* Additional fields for Pending Sale items */}
            {form.watch("status") === "pending-sale" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="sellingPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Selling Price</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                          <Input type="number" step="0.01" className="pl-8" placeholder="0.00" {...field} />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="buyerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Buyer Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter buyer's name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea 
                      rows={3} 
                      placeholder="Additional notes about this item..." 
                      {...field}
                      value={field.value || ""}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={updateItemMutation.isPending}
                className="bg-primary hover:bg-primary/90"
              >
                {updateItemMutation.isPending ? "Updating..." : "Update Item"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}