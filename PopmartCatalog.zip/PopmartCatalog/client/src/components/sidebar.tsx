import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Gamepad2, Zap, Sparkles, Star } from "lucide-react";

interface SidebarProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  selectedStatus: string;
  onStatusChange: (status: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

interface Stats {
  total: number;
  owned: number;
  wishlist: number;
  sold: number;
  totalValue: number;
  categories: {
    labubu: number;
    skullpanda: number;
    crybaby: number;
    other: number;
  };
}

export function Sidebar({ 
  selectedCategory, 
  onCategoryChange, 
  selectedStatus, 
  onStatusChange,
  searchQuery,
  onSearchChange 
}: SidebarProps) {
  const { data: stats } = useQuery<Stats>({
    queryKey: ["/api/stats"],
  });

  const categories = [
    { 
      id: "labubu", 
      name: "Labubu", 
      icon: Gamepad2, 
      count: stats?.categories.labubu || 0,
      active: selectedCategory === "labubu"
    },
    { 
      id: "skullpanda", 
      name: "Skullpanda", 
      icon: Zap, 
      count: stats?.categories.skullpanda || 0,
      active: selectedCategory === "skullpanda"
    },
    { 
      id: "crybaby", 
      name: "Crybaby", 
      icon: Sparkles, 
      count: stats?.categories.crybaby || 0,
      active: selectedCategory === "crybaby"
    },
    { 
      id: "other", 
      name: "Other Series", 
      icon: Star, 
      count: stats?.categories.other || 0,
      active: selectedCategory === "other"
    },
  ];

  return (
    <aside className="lg:w-64 space-y-6">
      {/* Search */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral w-4 h-4" />
          <Input
            type="text"
            placeholder="Search your collection..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
          />
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <h3 className="font-semibold text-gray-900 mb-3">Categories</h3>
        <Select value={selectedCategory} onValueChange={onCategoryChange}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Items</SelectItem>
            <SelectItem value="Anya">Anya</SelectItem>
            <SelectItem value="AZURA">AZURA</SelectItem>
            <SelectItem value="BAZBON">BAZBON</SelectItem>
            <SelectItem value="BOBO & COCO">BOBO & COCO</SelectItem>
            <SelectItem value="BUNNY">BUNNY</SelectItem>
            <SelectItem value="crybaby">Crybaby</SelectItem>
            <SelectItem value="DC">DC</SelectItem>
            <SelectItem value="DIMOO">DIMOO</SelectItem>
            <SelectItem value="Disney">Disney</SelectItem>
            <SelectItem value="DUCKOO">DUCKOO</SelectItem>
            <SelectItem value="FLABJACKS">FLABJACKS</SelectItem>
            <SelectItem value="Flying DongDong">Flying DongDong</SelectItem>
            <SelectItem value="FUBOBO">FUBOBO</SelectItem>
            <SelectItem value="Garfield">Garfield</SelectItem>
            <SelectItem value="Hacipupu">Hacipupu</SelectItem>
            <SelectItem value="Harry Potter">Harry Potter</SelectItem>
            <SelectItem value="Hirono">Hirono</SelectItem>
            <SelectItem value="inosoul">inosoul</SelectItem>
            <SelectItem value="Jackson Wang">Jackson Wang</SelectItem>
            <SelectItem value="KUBO">KUBO</SelectItem>
            <SelectItem value="labubu">Labubu</SelectItem>
            <SelectItem value="MIGO">MIGO</SelectItem>
            <SelectItem value="MINICO">MINICO</SelectItem>
            <SelectItem value="Minions">Minions</SelectItem>
            <SelectItem value="Molly">Molly</SelectItem>
            <SelectItem value="Nori">Nori</SelectItem>
            <SelectItem value="Nyota">Nyota</SelectItem>
            <SelectItem value="other">Other Series</SelectItem>
            <SelectItem value="Peach Riot">Peach Riot</SelectItem>
            <SelectItem value="Pino Jelly">Pino Jelly</SelectItem>
            <SelectItem value="POLAR">POLAR</SelectItem>
            <SelectItem value="POPMART">POPMART</SelectItem>
            <SelectItem value="Pucky">Pucky</SelectItem>
            <SelectItem value="SATYR RORY">SATYR RORY</SelectItem>
            <SelectItem value="skullpanda">Skullpanda</SelectItem>
            <SelectItem value="Snoopy">Snoopy</SelectItem>
            <SelectItem value="SpongeBob">SpongeBob</SelectItem>
            <SelectItem value="Sweet Bean">Sweet Bean</SelectItem>
            <SelectItem value="The Monsters">The Monsters</SelectItem>
            <SelectItem value="Twinkle Twinkle">Twinkle Twinkle</SelectItem>
            <SelectItem value="VITA">VITA</SelectItem>
            <SelectItem value="YOKI">YOKI</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Status Filter */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <h3 className="font-semibold text-gray-900 mb-3">Status</h3>
        <div className="space-y-2">
          <label className="flex items-center space-x-2 cursor-pointer">
            <Checkbox
              checked={selectedStatus === "owned"}
              onCheckedChange={(checked) => onStatusChange(checked ? "owned" : "")}
              className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
            />
            <span className="text-gray-700">Owned</span>
          </label>
          <label className="flex items-center space-x-2 cursor-pointer">
            <Checkbox
              checked={selectedStatus === "wishlist"}
              onCheckedChange={(checked) => onStatusChange(checked ? "wishlist" : "")}
              className="data-[state=checked]:bg-secondary data-[state=checked]:border-secondary"
            />
            <span className="text-gray-700">Wishlist</span>
          </label>
          <label className="flex items-center space-x-2 cursor-pointer">
            <Checkbox
              checked={selectedStatus === "sold"}
              onCheckedChange={(checked) => onStatusChange(checked ? "sold" : "")}
              className="data-[state=checked]:bg-accent data-[state=checked]:border-accent"
            />
            <span className="text-gray-700">Sold</span>
          </label>
          <label className="flex items-center space-x-2 cursor-pointer">
            <Checkbox
              checked={selectedStatus === "pending-sale"}
              onCheckedChange={(checked) => onStatusChange(checked ? "pending-sale" : "")}
              className="data-[state=checked]:bg-orange-500 data-[state=checked]:border-orange-500"
            />
            <span className="text-gray-700">Pending Sale</span>
          </label>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <h3 className="font-semibold text-gray-900 mb-3">Collection Stats</h3>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Total Items</span>
            <span className="font-semibold text-primary">{stats?.total || 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Wishlist</span>
            <span className="font-semibold text-secondary">{stats?.wishlist || 0}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Total Value</span>
            <span className="font-semibold text-accent">
              ${stats?.totalValue?.toFixed(2) || "0.00"}
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
