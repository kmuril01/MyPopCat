import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, MoreHorizontal, Edit } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { EditItemModal } from "@/components/edit-item-modal";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Item } from "@shared/schema";

interface ItemCardProps {
  item: Item;
  onUpdate: () => void;
  viewMode?: "grid" | "list";
}

export function ItemCard({ item, onUpdate, viewMode = "grid" }: ItemCardProps) {
  const [isWishlist, setIsWishlist] = useState(item.status === "wishlist");
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toggleWishlistMutation = useMutation({
    mutationFn: async () => {
      const newStatus = isWishlist ? "owned" : "wishlist";
      await apiRequest("PATCH", `/api/items/${item.id}`, { status: newStatus });
      return newStatus;
    },
    onSuccess: (newStatus) => {
      setIsWishlist(newStatus === "wishlist");
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: newStatus === "wishlist" ? "Added to wishlist" : "Marked as owned",
        description: `${item.name} has been updated.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update item status.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/items/${item.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Item deleted",
        description: `${item.name} has been removed from your collection.`,
      });
      onUpdate();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete item.",
        variant: "destructive",
      });
    },
  });

  const getStatusBadge = () => {
    switch (item.status) {
      case "owned":
        return <Badge className="bg-green-500 text-white">Owned</Badge>;
      case "wishlist":
        return <Badge className="bg-secondary text-white">Wishlist</Badge>;
      case "sold":
        return <Badge className="bg-accent text-white">Sold</Badge>;
      default:
        return null;
    }
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return null;
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const primaryImage = item.images && item.images.length > 0 ? item.images[0] : null;

  if (viewMode === "list") {
    return (
      <Card className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden">
        <div className="flex">
          <div className="relative w-32 h-32 bg-gray-100 overflow-hidden flex-shrink-0">
            {primaryImage ? (
              <img
                src={primaryImage}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-400">
                <span className="text-2xl">📦</span>
              </div>
            )}
          </div>
          <CardContent className="flex-1 p-4">
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-gray-900">{item.name}</h3>
                  {getStatusBadge()}
                </div>
                {item.series && (
                  <p className="text-gray-600 text-sm mb-2">{item.series}</p>
                )}
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  <span className="text-primary font-semibold">
                    {item.price ? `$${parseFloat(item.price).toFixed(2)}` : "—"}
                  </span>
                  <span>
                    {item.status === "sold" && item.soldDate
                      ? formatDate(item.soldDate)
                      : item.purchaseDate
                      ? formatDate(item.purchaseDate)
                      : "—"}
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="w-8 h-8"
                  onClick={() => toggleWishlistMutation.mutate()}
                  disabled={toggleWishlistMutation.isPending}
                >
                  <Heart
                    className={`w-4 h-4 ${
                      isWishlist ? "fill-red-500 text-red-500" : "text-gray-400"
                    }`}
                  />
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-8 h-8"
                    >
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem
                      onClick={() => setIsEditModalOpen(true)}
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Item
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => deleteMutation.mutate()}
                      className="text-red-600"
                    >
                      Delete Item
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </CardContent>
        </div>
        
        <EditItemModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSuccess={onUpdate}
          item={item}
        />
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden">
      <div className="relative">
        <div className="w-full h-48 bg-gray-100 overflow-hidden">
          {primaryImage ? (
            <img
              src={primaryImage}
              alt={item.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-400">
              <span className="text-4xl">📦</span>
            </div>
          )}
        </div>
        <div className="absolute top-3 right-3 flex gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="w-8 h-8 bg-white/90 hover:bg-white rounded-full"
            onClick={() => toggleWishlistMutation.mutate()}
            disabled={toggleWishlistMutation.isPending}
          >
            <Heart
              className={`w-4 h-4 ${
                isWishlist ? "fill-red-500 text-red-500" : "text-gray-400"
              }`}
            />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="w-8 h-8 bg-white/90 hover:bg-white rounded-full"
              >
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem
                onClick={() => setIsEditModalOpen(true)}
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit Item
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => deleteMutation.mutate()}
                className="text-red-600"
              >
                Delete Item
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="absolute bottom-3 left-3">
          {getStatusBadge()}
        </div>
      </div>
      <CardContent className="p-4">
        <h3 className="font-semibold text-gray-900 mb-1 truncate">{item.name}</h3>
        {item.series && (
          <p className="text-gray-600 text-sm mb-2 truncate">{item.series}</p>
        )}
        <div className="flex justify-between items-center">
          <span className="text-primary font-semibold">
            {item.purchasePrice || item.price ? `$${parseFloat(item.purchasePrice || item.price || '0').toFixed(2)}` : "—"}
          </span>
          <span className="text-xs text-gray-500">
            {item.status === "sold" && item.soldDate
              ? formatDate(item.soldDate)
              : item.purchaseDate
              ? formatDate(item.purchaseDate)
              : "—"}
          </span>
        </div>
      </CardContent>
      
      <EditItemModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSuccess={onUpdate}
        item={item}
      />
    </Card>
  );
}
